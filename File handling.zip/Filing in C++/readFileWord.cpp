#include <fstream>
#include <iostream>
#include <string>

using namespace std;

int main()
{
	fstream file;
	file.open("info.txt",ios::in);

    if (!file)
		cout << "No file found.....!";
	else {
        string word;

        while (file >> word) {
            cout << word << " ";
        }
        file.close();
	}

	return 0;
}
