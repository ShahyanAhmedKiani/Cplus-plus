#include<iostream>
#include<fstream>

using namespace std;

int main() {
    fstream file;
    file.open("info.txt", ios::app);
    if (!file) {
        cout<<"Error! Couldn\'t create file.....!";
    }
    else {
        cout<<"File created.....!"<<endl;
        file<<"This is the one line printing on the file"<<endl;
        cout<<"Wrote the information to the file.....!";
        file.close();
    }
    return 0;
}
