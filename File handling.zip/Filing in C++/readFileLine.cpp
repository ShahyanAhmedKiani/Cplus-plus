#include <fstream>
#include <iostream>
#include <string>

using namespace std;

int main()
{
	fstream file;
	file.open("info.txt",ios::in);

    if (!file)
		cout << "No file found.....!";
	else {
        string line;

        while (getline(file,line)) {
            cout << line << endl;
        }
        file.close();
	}

	return 0;
}
